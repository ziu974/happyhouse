<template>
  <div style="margin-top: 120px">
    <b-container class="bv-example-row mt-3 text-center">
      <h1 class="display-3">QnA</h1>
      <!-- <h3 class="underline-hotpink"><b-icon icon="question"></b-icon>QnA Service</h3> -->
      <router-view></router-view>
    </b-container>
  </div>
</template>
<script>
export default {
  name: "Qna",
};
</script>
<style scoped>
.underline-hotpink {
  display: inline-block;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0) 70%, rgba(231, 27, 139, 0.3) 30%);
}
</style>
