<template>
  <li>
    <b-row class="m-2" @click="selectHouse" @mouseover="colorChange(true)" @mouseout="colorChange(false)" :class="{ 'mouse-over-bgcolor': isColor }">
      <b-col cols="2" class="text-center align-self-center">
        <b-img thumbnail src="https://picsum.photos/250/250/?image=58" alt="Image 1"></b-img>
      </b-col>
      <b-col cols="10" class="align-self-center"> [{{ house.일련번호 }}] {{ house.아파트 }} </b-col>
    </b-row>
  </li>
</template>

<script>
import { mapActions } from "vuex";

const houseStore = "houseStore";

export default {
  name: "HouseListRow",
  data() {
    return {
      isColor: false,
    };
  },
  //// props: ["house"] (리마인드 - 비추하는 방식, type만이라도 지정하자)
  props: {
    house: Object,
  },
  created() {
    // console.log(this.house);
  },
  methods: {
    ...mapActions(houseStore, ["detailHouse"]),
    colorChange(flag) {
      this.isColor = flag;
    },
    selectHouse() {
      this.detailHouse(this.house);
    },
  },
};
</script>

<style scoped>
.apt {
  width: 50px;
}
.mouse-over-bgcolor {
  background-color: lightblue;
}
</style>
